% function f = getpid
%
% return the process ID for this instance of MATLAB.
