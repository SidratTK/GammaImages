function f = alwaysone(varargin)

% function f = alwaysone(varargin)
%
% <varargin> is anything
%
% return 1.
%
% example:
% isequal(alwaysone(23,[4 2]),1)

f = 1;
