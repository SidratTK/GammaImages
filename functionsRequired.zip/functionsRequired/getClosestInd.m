function [ind] = getClosestInd(InVector,InScalar,exFlag)
% which index of vector is closest in value to the scalar given?
% exFlag - for exact value matched.
if ~exist('exFlag','var'), exFlag = 0; end

diffis = InVector - repmat(InScalar, size(InVector));
diffis = abs(diffis);
ind = find(diffis == min(diffis));
if exFlag
    ind = find(diffis == 0);
end
end