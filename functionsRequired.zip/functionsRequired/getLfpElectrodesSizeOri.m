% function to get the LFP electrodes for Size ori of alpaH and kesariH.
% more than one LFP electrode can be obtained for each size ori session.
% alpaH had 15 such sessions, and kesariH had 6. 
% This function uses functions modified from Agrita's comparision paper codes
% STK 290420. 

function [elecListAll,expDateAll,protocolNameAll] =getLfpElectrodesSizeOri(subjectName,gridType,folderSourceString)

%getElecList
if strcmp(subjectName,'kesariH')
    load([subjectName,'MicroelectrodeRFData_Two.mat'],'highRMSElectrodes','rfStats');     % should be on path
else 
    % load(['F:\Programs\DataMAP\ReceptiveFieldData\',subjectName,'MicroelectrodeRFData.mat'],'rfStats');  % load RF data
    load([subjectName,'MicroelectrodeRFData.mat'],'highRMSElectrodes','rfStats');     % should be on path
end

elecListLFP = highRMSElectrodes(highRMSElectrodes<82);

[expDates,protocolNames] = getExpDateSizeSFOri(subjectName,gridType,'','SizeOri');
numDays=length(expDates);
elecListAll=[];
expDateAll ={};
protocolNameAll={};

for j=1:numDays
    expDate=expDates{j};
    protocolName=protocolNames{j};
    
    elecListEachDay=getElecListLFP(subjectName,folderSourceString,gridType,expDate,protocolName,elecListLFP,rfStats);
    
    if ~isempty(elecListEachDay)
        elecListAll = cat(2,elecListAll,elecListEachDay);
        expDateAll  = cat(2,expDateAll, repmat({expDate},[1,length(elecListEachDay)]));
        protocolNameAll  = cat(2,protocolNameAll, repmat({protocolName},[1,length(elecListEachDay)]));
    end    
end


end


function elecListEachDay=getElecListLFP(subjectName,folderSourceString,gridType,expDate,protocolName,elecListLFP,rfStats)

%getPositionList
load(fullfile(folderSourceString,'data',subjectName,gridType,expDate,protocolName,'extractedData','stimResults.mat'));
a=stimResults.azimuth(1);
e=stimResults.elevation(1);         
dRange   = [0 0.2];%electrodes which are within 0.2degree of stimulus center
impedanceCutoff = 2500;

for i=1:length(elecListLFP)
    elec=elecListLFP(i);
    azi = rfStats(elec).meanAzi;
    ele = rfStats(elec).meanEle;
        
    d(i) = sqrt(sum((azi-a)^2+(ele-e)^2));
end
elecListEachDay = elecListLFP(intersect(find(d>=dRange(1)),find(d<dRange(2))));
    
impedanceFile=fullfile(folderSourceString,'data',subjectName,gridType,expDate,'impedanceValues.mat');
if exist(impedanceFile,'file')
    load(fullfile(impedanceFile));
    badElectrodeList = find(impedanceValues>impedanceCutoff);
    elecListEachDay=setdiff(elecListEachDay,badElectrodeList);
end

%otherCriterion
if ~isempty(elecListEachDay) 
    clear frData numSpikes N
    [allFiringRates] = getFiringRates(subjectName,gridType,expDate,protocolName,folderSourceString,elecListEachDay);
    snrs = getSNR(subjectName,gridType,expDate,protocolName,folderSourceString,elecListEachDay);
     
    %getElectrodes with SNR>1.5
    snrCutOff=1.5;
    goodSNRelecs=elecListEachDay(find(snrs> snrCutOff));
    
%   getElectrodesHavingFiringRateof1spike/sforatleastoneofthesize
    goodSpikePos=intersect(find(max(allFiringRates)>1),find(min(allFiringRates)>1));
    goodFiringElecs=elecListEachDay(goodSpikePos);
    
    clear elecListEachDay
    elecListEachDay=intersect(goodSNRelecs,goodFiringElecs);
    disp([expDate ':numElectrodes-' num2str(elecListEachDay)]); 
else
    disp([expDate 'no Electrodes found']); 
end

end

function [frData,numSpikes,numStimuli] = getFiringRates(subjectName,gridType,expDate,protocolName,folderSourceString,electrodeList) %SRfunction modified
OriProtocol='SizeOri';
if strcmp(subjectName,'abu') || strcmp(subjectName,'rafiki')
    timeRangeForFRComputation=[0.2 0.4];
elseif strcmp(subjectName,'tutu') ||strcmp(subjectName,'alpaH')||strcmp(subjectName,'kesariH')
    timeRangeForFRComputation=[0.25 0.75];    % keep same for consistency (STK)
end
delT = timeRangeForFRComputation(2) - timeRangeForFRComputation(1);

if strcmp(subjectName,'rafiki') && strcmp(gridType,'Microelectrode') 
    fPos = 2;
else
    fPos = 1;
end

%getSizeVals
[sizeVals]=getSizeVals(subjectName,gridType,folderSourceString,OriProtocol,electrodeList(1));

% Get bad trials
load(fullfile(folderSourceString,'data',subjectName,gridType,expDate,protocolName,'segmentedData','badTrials.mat'));
[allStimPos{1},allStimPos{2}]= getStimPos(subjectName,gridType,expDate,protocolName,folderSourceString);

% Get timeVals
load(fullfile(folderSourceString,'data',subjectName,gridType,expDate,protocolName,'segmentedData','LFP','lfpInfo.mat'));

%loadParameterCombinatios
load(fullfile(folderSourceString,'data',subjectName,gridType,expDate,protocolName,'extractedData','parameterCombinations'));

% Spike Data
for i=1:length(electrodeList)
    for sizeNum=1:length(sizeVals)
        
        clear goodPos
        stimPosNum = 1;
        if stimPosNum==1 % GreaterThanOne
            goodPos = intersect(parameterCombinations{1,1,sizeNum,fPos,end},allStimPos{2});
        elseif stimPosNum==2 % Equal To One
            goodPos = intersect(parameterCombinations{1,1,sizeNum,fPos,end},allStimPos{1});
        else
            goodPos = intersect(parameterCombinations{1,1,sizeNum,fPos,end},[allStimPos{1} allStimPos{2}]);
        end
        goodPos = setdiff(goodPos,badTrials);
        numStimuli(sizeNum,i) = length(goodPos);
        
        load(fullfile(folderSourceString,'data',subjectName,gridType,expDate,protocolName,'segmentedData','Spikes',['elec' num2str(electrodeList(i)) '_SID0.mat']));
        
        spkCnt = getSpikeCounts(spikeData(goodPos),[timeRangeForFRComputation(1) timeRangeForFRComputation(2)]);
        frData(sizeNum,i) = mean(spkCnt)/delT;
        numSpikes(sizeNum,i) = sum(spkCnt);
        
    end
end
end

function [allStimPosEqualToOne,allStimPosGreaterThanOne]= getStimPos(subjectName,gridType,expDate,protocolName,folderSourceString)

folderName = fullfile(folderSourceString,'data',subjectName,gridType,expDate,protocolName);
folderExtract = fullfile(folderName,'extractedData');

load(fullfile(folderExtract,'goodStimNums.mat'));
load(fullfile(folderExtract,'stimResults.mat'));
goodStimPos = stimResults.stimPosition(goodStimNums);

if exist([folderExtract 'validStimAfterTarget.mat'],'file')
    load([folderExtract 'validStimAfterTarget.mat']);
    goodStimPos(validStimuliAfterTarget)=-1;  % These will be not be included in either stimPos==1 or stimPos>1
end

allStimPosEqualToOne = find(goodStimPos==1);
allStimPosGreaterThanOne = find(goodStimPos>1);
end

function snrs = getSNR(subjectName,gridType,expDate,protocolName,folderSourceString,electrodeList)

load(fullfile(folderSourceString,'data',subjectName,gridType,expDate,protocolName,'segmentedData','Segments','snrData.mat'));

allSNRs = signal./noise;
snrs = allSNRs(electrodeList);
end

function [sizeVals]=getSizeVals(subjectName,gridType,folderSourceString,OriProtocol,elec)
if ~exist('elec','var');     elec=0;                  end
[expDates,protocolNames] =  getExpDateSizeSFOri(subjectName,gridType,elec,OriProtocol);

if strcmp(subjectName,'tutu') || strcmp(subjectName,'alpaH') || strcmp(subjectName,'kesariH')
    load(fullfile(folderSourceString,'data',subjectName,gridType,expDates{1},protocolNames{1},'extractedData','parameterCombinations'),'sValsUnique');
    sizeVals=sValsUnique;
elseif strcmp(subjectName,'abu') || strcmp(subjectName,'rafiki')
    load(fullfile(folderSourceString,'data',subjectName,gridType,expDates{1},protocolNames{1},'extractedData','parameterCombinations'),'rValsUnique');
    sizeVals=rValsUnique;
end
end
