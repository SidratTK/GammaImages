
% STK 14May2020
% updated 161120
% 241120: removed getResponses.m and put that in separate function in
% functionsRequired folder

function [delGammaBand,electrodeList] = getGammaAllImages(folderSourceString,gridType,rootPath,dataDir,subjectNames,tBL,tST,numTapers,fBands,fBad,fBandG,useNotchData,methodFlag)
% function to get the gamma and broadband power and save them 

if ~exist('gridType','var'),            gridType    = 'Microelectrode'; end
if ~exist('folderSourceString','var'),      folderSourceString = 'W:\'; end
if ~exist('rootPath','var'),            rootPath = gammaModelPath_st(); end
if ~exist('dataDir','var'),        dataDir = fullfile(rootPath,'Data'); end
if ~exist('tBL','var'),                                 tBL =[-0.25 0]; end %
if ~exist('tST','var'),                                tST =[0.25 0.5]; end % 
if ~exist('numTapers','var'),                            numTapers=  3; end
if ~exist('useNotchData','var'),                       useNotchData =0; end   % use 1 or 0. 0= not notched
if ~exist('methodFlag','var'),                           methodFlag =0; end

if ~exist('fBands','var'),fBands = {[8 12] [35 70] [80 148] [150 250]}; end
if ~exist('fBandG','var'),                           fBandG = [35 70] ; end
if ~exist('fBad','var'),                                     fBad = []; end
if ~exist('subjectNames','var'),    subjectNames = {'alpaH','kesariH'}; end

% get electrodes LFP & Ecog
[~,~,LFPElectrodeList,EcogElectrodeList,subjectNames] = getRFdetails(subjectNames,dataDir);

fileName1 = fullfile(dataDir,'allStimuli_noDS.mat');
load(fileName1, 'ImageLabels','imageIndsCat', 'Categories');

if methodFlag==0   % use db change in power as we do in Ray Lab
    [delGammaBand,electrodeList]= savePwrSpectraMethod0(gridType,folderSourceString,subjectNames,LFPElectrodeList,EcogElectrodeList,ImageLabels,fBands,fBad,fBandG,Categories,imageIndsCat,tST,tBL,numTapers,methodFlag,useNotchData,dataDir);            
else               % use Gaussian fit to Gamma peak as in Hermes et al.
    savePwrSpectraMethod1(gridType,folderSourceString,subjectNames,LFPElectrodeList,EcogElectrodeList,ImageLabels,fBands,fBad,Categories,imageIndsCat,tST,tBL,numTapers,methodFlag,useNotchData,dataDir)
end

end

function [delGamma,electrodeList] = savePwrSpectraMethod0(gridType,folderSourceString,subjectNames,LFPElectrodeList,EcogElectrodeList,ImageLabels,fBands,fBad,fband, Categories,imageIndsCat,tST,tBL,numTapers,methodFlag,useNotchData,dataDir)

for m = 1: length(subjectNames)   % for each subject
    savefileis = fullfile(dataDir,'derivatives',['allImgStimuliPowerSp_',subjectNames{m},'_st_',num2str(tST(1)*1000),'_',num2str(tST(2)*1000),'_bl_',num2str(tBL(1)*1000),'_',num2str(tBL(2)*1000),'_method',num2str(methodFlag),'_notch',num2str(useNotchData),'.mat']);
    if ~exist(savefileis,'file')
    logDelPwrLfpBand = single(zeros(length(LFPElectrodeList{m}), length(ImageLabels), length(fBands)));
    logDelPwrEcogBand= single(zeros(length(EcogElectrodeList{m}), length(ImageLabels), length(fBands)));
    
    for catNum = 1:length(Categories)        % for each stimulus category
        catName = Categories{catNum};
        disp(catName);
        store_inds = imageIndsCat{catNum};
        [subjects, expDates, protocolNames,~,SInds,~,typeProtocol,fPos] = getProtocolInfo(catName); % get corresponding protocol details
        [~,ind1] = intersect(subjects,subjectNames(m));
        if isempty(ind1)   
             continue;         % no protocol for this monkey, move to next iteration
        end 
        subjectName   = subjects{ind1};
        expDate       = expDates{ind1}; 
        protocolName  = protocolNames{ind1};
        stimIndsToChoose= SInds{ind1};
        
        dir = fullfile(dataDir,'derivatives','Spectra','savedDataImages');
        [pwrLfpST,pwrLfpBL,freqVals,pwrEcogST,pwrEcogBL,LFPElectrodes,EcogElectrodes] = getResponses(gridType,folderSourceString,subjectName,expDate,protocolName,typeProtocol,tBL,tST,numTapers,stimIndsToChoose,fPos,dir);

        if ~isequal(LFPElectrodes(:),LFPElectrodeList{m}(:)) || ~isequal(EcogElectrodes(:),EcogElectrodeList{m}(:))   % SANITY
            disp(['Check electrode list for ',subjectName,expDate,protocolName]);
            continue;
        end
        
        for el = 1:length(LFPElectrodes)  % for each electrode
            [temp1,temp2,temp3] = getPowerChanges(pwrLfpST(el,:),pwrLfpBL(el,:),freqVals,fBands,fBad);
            logDelPwrLfpBand(el,store_inds,:)=temp1; stPwrLfp(el,store_inds,:)=temp2; blPwrLfp(el,catNum,:)=temp3; 
        end                               
        for el = 1:length(EcogElectrodes)
            [temp1,temp2,temp3] = getPowerChanges(pwrEcogST(el,:),pwrEcogBL(el,:),freqVals,fBands,fBad);
            logDelPwrEcogBand(el,store_inds,:)=temp1; stPwrEcog(el,store_inds,:)=temp2; blPwrEcog(el,catNum,:)=temp3;
        end                               % end electrode

    end % end stim category

    % save for each subject 
    save(savefileis,'logDelPwrLfpBand','logDelPwrEcogBand','stPwrLfp','stPwrEcog','blPwrLfp','blPwrEcog','fBands','fBad','numTapers','Categories','imageIndsCat','LFPElectrodes','EcogElectrodes');
    
    else
    load(savefileis);
    end
    
    fbind = find(cell2mat(cellfun(@(x) isequal(x,fband), fBands,'un',0))==1);
    electrodeList= cat(1,LFPElectrodes,EcogElectrodes);
    
    if ~isempty(fbind)   % assign band power. 
        delGammaLfp  = (10.^squeeze((logDelPwrLfpBand(:,:,fbind))));   
        delGammaEcog = (10.^squeeze((logDelPwrEcogBand(:,:,fbind))));  
        delGamma     = cat(1,delGammaLfp,delGammaEcog);
        
    else  
        meanPwrBLall = cat(1,blPwrLfp,blPwrEcog);
        meanPwrST    = cat(1,stPwrLfp,stPwrEcog);
        [~,numStimuli1,~]  = size(stPwrLfp); 
        stBandPwr    = zeros(length(electrodeList),numStimuli1);
        blBandPwr    = zeros(length(electrodeList),1);
        [~,Bads]     = intersect(freqVals,fBad);
        f_inds       = freqVals>=fband(1) & freqVals<=fband(2);
        f_inds(Bads) = 0;
        for elec = 1:length(electrodeList)
            blBandPwr(elec) = sum(squeeze(meanPwrBLall(elec,f_inds)));
            for imPos = 1:numStimuli1  
                stBandPwr(elec,imPos) = sum(squeeze(meanPwrST(elec,imPos,f_inds))); 
                delGamma(elec,imPos) = (stBandPwr(elec,imPos))./(blBandPwr(elec));
            end 
        end 
    end 
      
end 
end

function [logPwrChange,meanPwrST,meanPwrBLall,stBandPwr,blBandPwr] = getPowerChanges(powerST,powerBL,freqVals,fBands,fBad)
% function to get change in power in given ranges
    [numElecs,numStimuli,~] = size(powerBL);
    
    meanPwrBL = zeros([numElecs,numStimuli,length(freqVals)]);
    meanPwrST = zeros([numElecs,numStimuli,length(freqVals)]);
    clear meanPwrBLall   
    for elec = 1:numElecs
        for oPos = 1:numStimuli                                     % for each stimulus
            allLFPDataBL = (powerBL{elec,oPos});
            allLFPDataST = (powerST{elec,oPos});
            meanPwrBL(elec,oPos,:) = mean(allLFPDataBL,2);          % mean across trials
            meanPwrST(elec,oPos,:) = mean(allLFPDataST,2);     
        end             % end stimulus
        meanPwrBLall(elec,:) = mean(meanPwrBL(elec,:,:),2);        % get average baseline across all stimuli
    end           

   % get gamma & BB power
   logPwrChange = zeros(numElecs,numStimuli,length(fBands));
   stBandPwr    = zeros(numElecs,numStimuli,length(fBands));
   blBandPwr    = zeros(numElecs,length(fBands));
   [~,Bads] = intersect(freqVals,fBad);
   for ii=1:length(fBands)
       fBand = fBands{ii};
       f_inds = freqVals>=fBand(1) & freqVals<=fBand(2);
       f_inds(Bads) = 0;
       for elec = 1:numElecs
           blBandPwr(elec,ii) = sum(squeeze(meanPwrBLall(elec,f_inds)));
           for oPos = 1:numStimuli
              stBandPwr(elec,oPos,ii) = sum(squeeze(meanPwrST(elec,oPos,f_inds))); 
              logPwrChange(elec,oPos,ii) = log10(stBandPwr(elec,oPos,ii)) - log10(blBandPwr(elec,ii));
           end 
       end 
   end


end

function [] =savePwrSpectraMethod1(gridType,folderSourceString,subjectNames,LFPElectrodeList,EcogElectrodeList,ImageLabels,fBands,fBad,Categories,imageIndsCat,tST,tBL,numTapers,methodFlag,useNotchData,dataDir)
% CHECK COMPATIBILITY OF THIS FUNCTION, NOT TESTED FOR MODEL2 - STK
if ~exist('useNotchData','var'), useNotchData=0; end

% nr of bootstrap for resampling per stimulus
nr_boots = 200;
% freqs to use in fitting
f_use4fit = setdiff([28:200], fBad);   
alphBand = fBands{1};

for m = 1: length(subjectNames)   % for each subject
    resamp_parmsLfp = {};  fitSTLfp = {}; %  initialise outputs
    resamp_parmsEcog = {}; fitSTEcog ={};
    savefileis = fullfile(dataDir,'derivatives',...
        ['allStimuliPowerSp_',subjectNames{m},'_st_',num2str(tST(1)*1000),'_',num2str(tST(2)*1000),'_bl_',num2str(tBL(1)*1000),'_',num2str(tBL(2)*1000),'_method',num2str(methodFlag),'_notch',num2str(useNotchData),'.mat']);
    
    for catNum = 1:length(Categories)        % for each stimulus category
        catName = Categories{catNum};
        disp(catName);
        store_inds = imageIndsCat{catNum};
        [subjects, expDates, protocolNames,~,SInds,~,typeProtocol,fPos] = getProtocolInfo(catName); % get corresponding protocol details
        [~,ind1] = intersect(subjects,subjectNames(m));
        if isempty(ind1)   
             continue;         % no protocol for this monkey, move to next iteration
        end 
        subjectName   = subjects{ind1};
        expDate       = expDates{ind1}; 
        protocolName  = protocolNames{ind1};
        stimIndsToChoose= SInds{ind1};
        
        [pwrLfpST,pwrLfpBL,freqVals,pwrEcogST,pwrEcogBL,LFPElectrodes,EcogElectrodes] = ...
            getResponses(gridType,folderSourceString,subjectName,expDate,protocolName,typeProtocol,tBL,tST,numTapers,stimIndsToChoose,fPos,dataDir,useNotchData);

        if ~isequal(LFPElectrodes(:),LFPElectrodeList{m}(:)) || ~isequal(EcogElectrodes(:),EcogElectrodeList{m}(:))   % SANITY
            disp(['Check electrode list for ',subjectName,expDate,protocolName]);
            continue;
        end
        
%         parfor el = 1:length(LFPElectrodes)  % for each electrode
%             [resamp_parmsLfp{el}(store_inds,:,:),fitSTLfp{el}(store_inds,:),resamp_parmsDetail] = getPowerFits(pwrLfpST(el,:),pwrLfpBL(el,:), freqVals,f_use4fit,alphBand,nr_boots);
%         end        
        fitSTLfp = 'DO-THIS_LATER';
        resamp_parmsLfp= 'COMPUTE-THIS_LATER';
        
        for el = 1:length(EcogElectrodes)
            [resamp_parmsEcog{el}(store_inds,:,:),fitSTEcog{el}(store_inds,:),resamp_parmsDetail]= getPowerFits(pwrEcogST(el,:),pwrEcogBL(el,:),freqVals,f_use4fit,alphBand,nr_boots);
        end                     % end electrode
       
        % save for each subject in each iteration, as it takes  long time to run
        save(savefileis,'resamp_parmsLfp','resamp_parmsEcog','fitSTLfp','fitSTEcog','f_use4fit','alphBand','numTapers','Categories','imageIndsCat','LFPElectrodes','EcogElectrodes','resamp_parmsDetail','freqVals','tBL','tST');
   
    end  % end stim category 
   
end     % end subj


end 

function [resamp_parms,fit_is,resamp_parmsDetail] = getPowerFits(powerST,powerBL,freqVals,f_use4fit,alphBand,nr_boots)

[numElecs,numStimuli,~] = size(powerBL);
f_alpha = find(freqVals>=alphBand(1) & freqVals<=alphBand(2));

% define output:
resamp_parms = NaN(numStimuli,nr_boots,7);
fit_is       = NaN(numStimuli,nr_boots,length(freqVals));

meanPwrBL = zeros([numStimuli,length(freqVals)]);
clear meanPwrBLall   
    for oPos = 1:numStimuli                                     % for each stimulus
        allLFPDataBL = (powerBL{1,oPos});
        meanPwrBL(oPos,:) = mean(allLFPDataBL,2);          % mean across trials
    end              % end stimulus
    data_BL = mean(meanPwrBL,1);         % for the baseline, do not resample, average across all trials
            
for oPos = 1:numStimuli
    disp(['fitting stimulus ' int2str(oPos) ' of ' int2str(numStimuli)]);
    for ii = 1:nr_boots
        % get stimulus data
        data_ST = powerST{1,oPos};
        data_ST = data_ST';    % trials x freq
        
        % from stimulus data, random sample with replacement
        trial_set = randsample(size(data_ST,1),size(data_ST,1),true);

        % average across resampled trials
        data_ST = mean(data_ST(trial_set,:),1);

        % do the fitting
        [out_exp,bb_amp,gamma_amp,gamma_freq,gamma_width,fit_f2] = ecog_fitgamma(freqVals',f_use4fit,data_BL,data_ST);
        resamp_parms(oPos,ii,1) = out_exp(1); % this is the slope used in all cases
        resamp_parms(oPos,ii,2) = bb_amp;
        resamp_parms(oPos,ii,3) = gamma_amp;
        resamp_parms(oPos,ii,4) = gamma_freq;
        resamp_parms(oPos,ii,5) = gamma_width;
        resamp_parms(oPos,ii,6) = out_exp(2); % this is the baseline intercept
        %  alpha change
        resamp_parms(oPos,ii,7) = mean(log10(data_ST(f_alpha)) - log10(data_BL(f_alpha)));
        fit_is(oPos,ii,:) = fit_f2;
    end
end
fit_is = squeeze(mean(fit_is,2));  
resamp_parmsDetail = {'BL Slope','Log10 BB Amp','Log10 Gamma Gaussian Amp over BB','Gamma Center Freq','Gamma Gaussian Width','BL intercept','Log10 Alpha Change'};
end


