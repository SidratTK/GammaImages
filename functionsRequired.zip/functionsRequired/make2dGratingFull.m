
function [grating] = make2dGratingFull(res,degppix,sf,ang,phase)
% full size grating

% cpfov = sf*degppix*res;    % cycles per field of view
% % make 2d grating using code from knkutils. Kay et al 2013
% [gratingFull,~,~] = makegrating2d(res,cpfov,ang,phase,[],[],r,c);

% template for generating grating
[x,y] = meshgrid(-ceil((res-1)/2):floor((res-1)/2));  % size & shape of matrix
 % apply rotation
xprime = -x*cos(ang)+ y*sin(ang); % -x,+y makes the grating CCW as ang increases. ang is the normal to grating
 % spatial phase offset per pixel?
xprime = xprime*sf*degppix; % pixels * cyclesperpixel
 % make grating
grating = cos(2*pi*xprime + phase);

end