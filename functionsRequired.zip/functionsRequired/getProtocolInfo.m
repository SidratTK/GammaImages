
% Given a category name, returns the protocol details for the 2 monkeys
% Labels is sometimes used in filename for saving 
% SInds is the index (1:16 or 17:32) of stimuli in the given category.
% Categories are:
% {'Gratings2cpd', 'Gratings4cpd','HueScreen','FaunaGray','FloraGray','TextureGray','LandscapeGray','FacesGray',
% 'Fauna','Flora','Texture','Landscape','Faces','FaunaScrGray','FaunaScr','TextureScr'};  


function [monkeys, expDates, protocolNames, Labels, SInds, ecogSims,typeProtocol,fPos] = getProtocolInfo(catName)

BWFlag = 0; scramFlag = 0;  % default
% this function returns specific protocols for required specs
if strcmp(catName(end-3:end),'Gray')
    BWFlag = 1; 
end
if strcmp(catName(end-2:end),'Scr')
    scramFlag = 1; 
end
if strfind(catName,'ScrGray')
    BWFlag = 1;  scramFlag = 1; 
end

if ~isempty(strfind(catName,'Fauna')) || ~isempty(strfind(catName,'Animals'))
    if BWFlag ==0 && scramFlag==0
        monkeys   =    {'alpaH' , 'kesariH'};                                   % 'alpaH' , 'kesariH', 
        expDates  =    {'010817',  '060318'};   % AF_32, AS_32                  % '300817', '020118', AS_32, AS_32, 
        protocolNames= {'GRF_001', 'GRF_002' };                                 %'GRF_002', 'GRF_001',
        Labels    =    {'1st_16set','1st_16set'};  SInds = {[1:16],  [1:16]};   % '1st_16set','1st_16set',   [1:16],  [1:16],  
        ecogSims  =  ones(size(monkeys));
        
    elseif BWFlag ==1 && scramFlag==0
        monkeys   =    {'alpaH' , 'kesariH'};    % 
        expDates  =    {'230817',  '150118'};    %   AF_32, AF_32, GRAY 
        protocolNames= {'GRF_001', 'GRF_001'};   % 
        Labels    =    {'1st_16set','1st_16set'};  SInds = {[1:16], [1:16]};   
        ecogSims  =  ones(size(monkeys));
        
    elseif BWFlag ==0 && scramFlag==1
        monkeys   =    {'alpaH' , 'kesariH'};
        expDates  =    {'300817', '020118'};     %  AS_32, AS_32 SCRAMBLE
        protocolNames= {'GRF_002', 'GRF_001'};
        Labels    =    {'2nd_16set','2nd_16set'};  SInds = {[17:32],  [17:32]};
        ecogSims  =  ones(size(monkeys));
    elseif BWFlag ==1 && scramFlag==1
        monkeys   =    {'alpaH' , 'kesariH'};
        expDates  =    {'200817', '230118'};    %  AS_32 gray, AS_32 gray SCRAMBLE also '010917' GRF_001 for alpaH
        protocolNames= {'GRF_001', 'GRF_002'};
        Labels    =    {'2nd_16set','2nd_16set'};  SInds = {[17:32],  [17:32]};
        ecogSims  =  ones(size(monkeys));
    end
    typeProtocol  = 'Images';
    fPos = 1;
    
elseif strfind(catName,'Flora')    
    if BWFlag ==0 && scramFlag==0
        monkeys   =    {'alpaH' , 'kesariH'};
        expDates  =    {'010817',  '060318'};   % AF_32, AF_32, 
        protocolNames= {'GRF_001', 'GRF_002'};
        Labels    =    {'2nd_16set','2nd_16set'};  SInds = {[17:32],  [17:32]};
        ecogSims  =  ones(size(monkeys));
        
    elseif BWFlag ==1 && scramFlag==0
        monkeys   =    {'alpaH' , 'kesariH'};    %  'alpaH' , 'kesariH'};
        expDates  =    {'230817',  '150118'};    %   AF_32, AF_32, GRAY 
        protocolNames= {'GRF_001', 'GRF_001'};   % 
        Labels    =    {'2nd_16set','2nd_16set'};  SInds = {[17:32], [17:32]};     % ,  [1:16],  [1:16]}; %,'1st_16set','1st_16set'};
        ecogSims  =  ones(size(monkeys));
    end
    typeProtocol  = 'Images';
    fPos = 1;
    
elseif strfind(catName,'Texture')
    if BWFlag ==0 && scramFlag==0
        monkeys   =    {'alpaH' , 'kesariH'};                                         % , 'alpaH' , 'kesariH'
        expDates  =    {'240817',  '030318'};    % TL_32, TL_32,                      % , '310817', '040118' % TS_32, TS_32
        protocolNames= {'GRF_002', 'GRF_003'};                                        % , 'GRF_003', 'GRF_001'
        Labels    =    {'1st_16set','1st_16set'};  SInds = {[1:16],  [1:16]};         % ,'1st_16set','1st_16set'  %  ,  [1:16],  [1:16]
        ecogSims  =  ones(size(monkeys));
        
    elseif BWFlag ==1 && scramFlag==0
        monkeys   =    {'alpaH' , 'kesariH'};   
        expDates  =    {'250817',  '170218'};    %   TL_32, TL_32, GRAY 
        protocolNames= {'GRF_002', 'GRF_001'};   % 
        Labels    =    {'1st_16set','1st_16set'};  SInds = {[1:16], [1:16]};    
        ecogSims  =  ones(size(monkeys));
        
    elseif BWFlag ==0 && scramFlag==1
        monkeys   =    {'alpaH' , 'kesariH'};
        expDates  =    {'310817', '040118'};    %  TS_32, TS_32 SCRAMBLE
        protocolNames= {'GRF_003', 'GRF_001'};
        Labels    =    {'2nd_16set','2nd_16set'};  SInds = {[17:32],  [17:32]};
        ecogSims  =  ones(size(monkeys));
    end
    typeProtocol  = 'Images';
    fPos = 1;
        
elseif strfind(catName,'Landscape')
    if BWFlag ==0 && scramFlag==0
        monkeys   =    {'alpaH' , 'kesariH'};
        expDates  =    {'240817',  '030318'};   % TL_32, TL_32
        protocolNames= {'GRF_002', 'GRF_003'};
        Labels    =    {'2nd_16set','2nd_16set'};  SInds = {[17:32],  [17:32]};
        ecogSims  =  ones(size(monkeys));
        
    elseif BWFlag ==1 && scramFlag==0
        monkeys   =    {'alpaH' , 'kesariH'};    %  'alpaH' , 'kesariH'};
        expDates  =    {'250817',  '170218'};    %   TL_32, TL_32, GRAY 
        protocolNames= {'GRF_002', 'GRF_001'};   % 
        Labels    =    {'2nd_16set','2nd_16set'};  SInds = {[17:32],  [17:32]};     % 
        ecogSims  =  ones(size(monkeys));
    end
    typeProtocol  = 'Images';
    fPos = 1;
    
elseif  strfind(catName,'Faces')
    if BWFlag ==0 && scramFlag==0
        monkeys   =    {'alpaH' , 'kesariH'};
        expDates  =    {'080817',  '050318'};   % TL_32, TL_32
        protocolNames= {'GRF_001', 'GRF_003'};
        Labels    =    {'1st_16set','1st_16set'};  SInds = {[1:16],  [1:16]};
        ecogSims  =  ones(size(monkeys));
        
    elseif BWFlag ==1 && scramFlag==0
        monkeys   =    {'alpaH' , 'kesariH'};    %  'alpaH' , 'kesariH'};
        expDates  =    {'110817',  '050118'};    %   
        protocolNames= {'GRF_003', 'GRF_003'};   % 
        Labels    =    {'1st_16set','1st_16set'};  SInds = {[1:16],  [1:16]};     % 
        ecogSims  =  ones(size(monkeys));
    end
    typeProtocol  = 'Images';
    fPos = 1;
    
elseif  strfind(catName,'Gratings2cpd')
    monkeys   =    {'alpaH' , 'kesariH'};
    expDates  =    {'240817', '050318'}; 
    protocolNames ={'GRF_001','GRF_001'}; 
    Labels    =    { 'all',  'all'};    SInds = {[1:8],  [1:8]};     % 
    ecogSims  =  ones(size(monkeys));
    typeProtocol = 'Ori';    % treat it like ori
    fPos = 1;

elseif  strfind(catName,'Gratings4cpd')
    monkeys   =    {'alpaH' , 'kesariH'};
    expDates  =    {'210817','060318'}; 
    protocolNames ={'GRF_003','GRF_001'}; 
    Labels    =    { 'all',  'all'};    SInds = {[1:8],  [1:8]};     % 
    ecogSims  =  ones(size(monkeys));
    typeProtocol = 'Ori';    % treat it like ori
    fPos = 1;

elseif strfind(catName,'HueScreen')
    monkeys   =    {'alpaH' , 'kesariH'};
    expDates  =    {'010917', '050318'}; 
    protocolNames ={'GRF_005','GRF_004'}; 
    Labels    =    { 'all',  'all'};    SInds = {[1:7],  [1:7]};     % 
    ecogSims  =  ones(size(monkeys));
    typeProtocol = 'Ori';    % treat it like ori
    fPos = 1;
end

end



