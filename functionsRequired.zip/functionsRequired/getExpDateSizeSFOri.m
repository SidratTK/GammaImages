
%For alpaH, more Size-Ori protocols were run in August2018. The stimulus
%size (sigma) was varied from 0.0125 to 9.6 in log scale. This information
%is under sizeOriExtendedflag
%V1 ECoGs AlpaH [82 85 86 88 89];
%V1 ECoGs KesariH [85 86 88 89];



function [expDate,protocolName] = getExpDateSizeSFOri(monkeyName,gridType,ECoGNumber,OriProtocol,sizeOriExtended)
if ~exist('ECoGNumber','var');             ECoGNumber=0;                end
if ~exist('OriProtocol','var');            OriProtocol='SFOri';         end
if ~exist('sizeOriExtended','var');        sizeOriExtended=0;           end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% ALPAH %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if strcmp(monkeyName,'alpaH') && strcmpi(gridType,'Microelectrode')
    [allExpDates,allProtocolNames] = allProtocolsAlpaHMicroelectrode_copy;   % read copy to bypass sqlite functions
    if strcmp(OriProtocol,'SizeOri')
        if ECoGNumber==82
            if sizeOriExtended
                protocolList=403;
            else
                protocolList=143;
            end
            
        elseif ECoGNumber==83
            protocolList=[146];
            
        elseif ECoGNumber==84
            protocolList=[66 136];
            
        elseif ECoGNumber==85
            if sizeOriExtended
                protocolList=406;
            else
                protocolList=132;
            end
            
        elseif ECoGNumber==86
            if sizeOriExtended
                protocolList=382;
            else
                protocolList=133;
            end
            
        elseif ECoGNumber==87
            protocolList=[68 144];
            
        elseif ECoGNumber==88
            if sizeOriExtended
                protocolList=407;
            else
                protocolList=69;
            end
            
        elseif ECoGNumber==89
            if sizeOriExtended
                protocolList=383;
            else
                protocolList=92;
            end
            
        else
            if sizeOriExtended
                protocolList=[384 390 391 392 393 394 395 396 398 399 400 401 402 404 405 408 409 410 411 413 414];
            else
                protocolList=[32 60 64 67 134 145 334 335 336 337 347 348 349 350 354];
            end
        end
        
    elseif strcmp(OriProtocol,'SFOri')
        protocolList=78;
    end
    
elseif strcmp(monkeyName,'kesariH') && strcmpi(gridType,'Microelectrode')
    [allExpDates,allProtocolNames] = allProtocolsKesariHMicroelectrode_copy;   % read copy to bypass sqlite functions
    if strcmp(OriProtocol,'SizeOri')
        if ECoGNumber==85
            protocolList=19;
        elseif ECoGNumber==86
            protocolList=37;
        elseif ECoGNumber==87
            protocolList=132;
        elseif ECoGNumber==88
            protocolList=47;
        elseif ECoGNumber==89
            protocolList=48;
        else
            protocolList=[72 161 162 163 164 166];
        end
    elseif strcmp(OriProtocol,'SFOri')
        protocolList=131;
    end
    
elseif  strcmp(monkeyName,'tutu') && strcmpi(gridType,'Microelectrode')
    [allExpDates,allProtocolNames] = allProtocolsTutuMicroelectrode;
    if strcmp(OriProtocol,'SizeOri')
        if ECoGNumber==83
            protocolList=[74 82];
        elseif ECoGNumber==85
            protocolList=[76];
        elseif ECoGNumber==86
            protocolList=[24];
        elseif ECoGNumber==87
            protocolList=[80];
        elseif ECoGNumber==88
            protocolList=[41];
        elseif ECoGNumber==89
            protocolList=[25];
        else
            protocolList=[23 28 38 63 64 77];
        end
    elseif strcmp(OriProtocol,'SFOri')
        protocolList=37;
    end
    
elseif strcmp(monkeyName,'rafiki') && strcmp(gridType,'Microelectrode')
    [allExpDates,allProtocolNames] = allProtocolsRafikiMicroelectrode;
    if strcmp(OriProtocol,'SizeOri')
        protocolList=[8 11 15 19 22 26 31 36 41 46 51 56 60 65 70 75 80 84 89 93 98 103 108 113];
    elseif strcmp(OriProtocol,'SFOri')
        protocolList= 16;
    end
elseif strcmp(monkeyName,'rafiki') && strcmp(gridType,'ECoG')
    [allExpDates,allProtocolNames] = allProtocolsRafikiECoG;
    if strcmp(OriProtocol,'SizeOri')
        protocolList=16;
    elseif strcmp(OriProtocol,'SFOri')
        protocolList=17;
    end
    
elseif strcmp(monkeyName,'abu') && strcmp(gridType,'Microelectrode')
    [allExpDates,allProtocolNames] = allProtocolsAbuMicroelectrode;
    if strcmp(OriProtocol,'SizeOri')
        protocolList=[275 276 278 280 282 285 287 289 291 294];
    end
    
elseif strcmp(monkeyName,'abu') && strcmp(gridType,'ECoG')
    [allExpDates,allProtocolNames] = allProtocolsAbuECoG;
    if strcmp(OriProtocol,'SizeOri')
        if ECoGNumber==33
            protocolList=[48];
        elseif ECoGNumber==34
            protocolList=[17];
        end
    end
end

if strcmp(OriProtocol,'SFOri')
    expDates = allExpDates(protocolList);
    expDate=expDates{1};
    protocolNames = allProtocolNames(protocolList); protocolName=protocolNames{1};   
elseif strcmp(OriProtocol,'SizeOri')
    expDate = allExpDates(protocolList);  
    protocolName = allProtocolNames(protocolList);
end

end

