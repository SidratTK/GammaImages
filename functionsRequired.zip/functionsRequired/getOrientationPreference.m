function [prefOri,oriSel] = getOrientationPreference(fRate,oValsUnique)

    
    num=0;
    den=0;
    
    for i=1:length(oValsUnique)
        num = num+fRate(i)*sind(2*oValsUnique(i));
        den = den+fRate(i)*cosd(2*oValsUnique(i));
    end
    
    prefOri = 90*atan2(num,den)/pi;
    oriSel = abs(den+1i*num)/sum(fRate);

    if (prefOri<0)
    prefOri = prefOri+180;
    end
    
end