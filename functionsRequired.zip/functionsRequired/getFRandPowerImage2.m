% This program saves the firing rate and power for the images protocol
% updated 14May2020
function [numSpikesST,numSpikesBL,powerST,powerBL,freqVals] = getFRandPowerImage2(subjectName,gridType,folderSourceString,expDates,protocolNames,goodElectrodeList,timeBL,timeST,estFlag,numTapers,saveFlag,dataDir,notchFlag)

if ~exist('notchFlag','var')    % 
    notchFlag = 0;
end
if ~exist('saveFlag','var')    % 
    saveFlag = 1;
end
if ~exist('estFlag','var')    % estFlag = 1 means MT, estFlag = 2 means MP
    estFlag = 1;
end 
if ~exist('numTapers','var')    % number of tapers for MT
    numTapers = 1;
end

if ~exist('timeBL','var')
    timeBL = [-0.25 0];
end
if ~exist('timeST','var')
    timeST = [0.25 0.5];
end

if ~iscell(expDates)
    expDatesTMP{1} = expDates;
    protocolNamesTMP{1} = protocolNames;
    
    clear expDates protocolNames
    expDates = expDatesTMP;
    protocolNames = protocolNamesTMP;
end
    
for i=1:length(expDates)
    expDate = expDates{i};
    protocolName = protocolNames{i};
    disp([expDate protocolName]);
    if nargout>2
        [numSpikesST{i},numSpikesBL{i},powerST{i},powerBL{i},freqVals] = getFRandPowerSingleDay(subjectName,expDate,protocolName,folderSourceString,gridType,goodElectrodeList,timeBL,timeST,estFlag,numTapers,saveFlag,dataDir,notchFlag);
    else
        [numSpikesST{i},numSpikesBL{i}] = getFRandPowerSingleDay(subjectName,expDate,protocolName,folderSourceString,gridType,goodElectrodeList,timeBL,timeST,estFlag,numTapers,saveFlag,dataDir,notchFlag);
    end 
end 
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [numSpikesST,numSpikesBL,powerST,powerBL,freqVals] = getFRandPowerSingleDay(subjectName,expDate,protocolName,folderSourceString,gridType,electrodeList,timeRangeForBLComputation,timeRangeForSTComputation,estFlag,numTapers,saveFlag,folderSave,notchFlag)

if numTapers>1, tapers = [ceil((numTapers+1)/2) numTapers]; 
else            tapers = [1 1];
end
numElectrodes = length(electrodeList);
if estFlag == 1
    fileSave = fullfile(folderSave,[subjectName expDate protocolName gridType '_N' num2str(numElectrodes) '_st_' num2str(1000*timeRangeForSTComputation(1)) '_' ...
    num2str(1000*timeRangeForSTComputation(2)) '_bl_' num2str(1000*timeRangeForBLComputation(1)) '_' num2str(1000*timeRangeForBLComputation(2)) '_tapers_' num2str(tapers(1)) '_' num2str(tapers(2)) '_notch' num2str(notchFlag) '.mat']);
else
    fileSave = fullfile(folderSave,[subjectName expDate protocolName gridType '_N' num2str(numElectrodes) '_st_' num2str(1000*timeRangeForSTComputation(1)) '_' ...
    num2str(1000*timeRangeForSTComputation(2)) '_bl_' num2str(1000*timeRangeForBLComputation(1)) '_' num2str(1000*timeRangeForBLComputation(2)) '_MP' '_notch' num2str(notchFlag) '.mat']);
end

if exist(fileSave,'file')
%     disp(['Loading ' fileSave]);
    x=load(fileSave);
    if isequal(x.electrodeList,electrodeList)
        numSpikesST = x.numSpikesST;
        numSpikesBL = x.numSpikesBL;
        powerST = x.powerST;
        powerBL = x.powerBL;
        freqVals = x.freqVals;
    end
else
    disp(['Generating ' fileSave]);
    
    % Get bad trials
    load(fullfile(folderSourceString,'data',subjectName,gridType,expDate,protocolName,'segmentedData','badTrials.mat'));
    
    % Get timeVals
    load(fullfile(folderSourceString,'data',subjectName,gridType,expDate,protocolName,'segmentedData','LFP','lfpInfo.mat')); 
    
    % Multi-taper
        Fs  =  round(1/(timeVals(2)-timeVals(1)));
        params.tapers   = tapers;
        params.pad      = -1;
        params.Fs       = Fs;
        params.fpass    = [0 250];
        params.trialave = 0;

    stPos  = find(timeVals>=timeRangeForSTComputation(1),1) + (0:round(Fs*diff(timeRangeForSTComputation))-1);
    blPos  = find(timeVals>=timeRangeForBLComputation(1),1) + (0:round(Fs*diff(timeRangeForBLComputation))-1);
    
     %%%%%%%%%%%%%%%%%%%%%%%%%%% Get Good StimPos %%%%%%%%%%%%%%%%%%%%%%%%%%
    clear goodStimPos
    x = load(fullfile(folderSourceString,'data',subjectName,gridType,expDate,protocolName,'extractedData','parameterCombinations.mat')); % ParameterCombinations
    aPos=1;ePos=1;rPos=1;oPos=1;cPos=1;tPos=1; %fPos=1; azim, ele, size, ori, con, tf
    numImages = length(x.fValsUnique);             % sfvals corresp to images
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for i=1:numElectrodes
        electrodeNum = electrodeList(i);
        % Get Spikes  %  account for sorted units
        if size(electrodeList,2)>1,
        spikefile=fullfile(folderSourceString,'data',subjectName,gridType,expDate,protocolName,'segmentedData','Spikes',['elec' num2str(electrodeNum) '_SID' num2str(electrodeList(i,2)) '.mat']);
        else
        spikefile=fullfile(folderSourceString,'data',subjectName,gridType,expDate,protocolName,'segmentedData','Spikes',['elec' num2str(electrodeNum) '_SID0.mat']);
        end
        
        if exist(spikefile,'file')
            load(spikefile);
        else
            spikeData=cell(1,1800); % when neural channel not found, create dummy file for spike data
        end
        % Get LFP Data
        if notchFlag==0
            load(fullfile(folderSourceString,'data',subjectName,gridType,expDate,protocolName,'segmentedData','LFP',['elec' num2str(electrodeNum) '.mat']));
        else
            load(fullfile(folderSourceString,'data',subjectName,gridType,expDate,protocolName,'notched','segmentedData','LFP',['elec' num2str(electrodeNum) '.mat']));
        end
         for fPos=1:numImages
              clear goodPos
              goodPos = setdiff(x.parameterCombinations{aPos,ePos,rPos,fPos,oPos,cPos,tPos},badTrials);

              numSpikesST{i,fPos} = getSpikeCounts(spikeData(goodPos),timeRangeForSTComputation); %#ok<*AGROW>
              numSpikesBL{i,fPos} = getSpikeCounts(spikeData(goodPos),timeRangeForBLComputation);
                
              if nargout >2  % Power
                 if estFlag==1
                     powerST{i,fPos} = mtspectrumc(analogData(goodPos,stPos)',params);
                     [powerBL{i,fPos},freqVals]=mtspectrumc(analogData(goodPos,blPos)',params);
                 else 
                     powerTemp = getspectraMP(analogData(goodPos,:)',analogInfo,blPos,stPos);
                     powerST{i,fPos} = powerTemp.STenergy;  powerBL{i,fPos} = powerTemp.BLenergy;
                     freqVals = powerTemp.freq;
                 end 
              else 
                    powerST=[]; powerBL=[]; freqVals=[];
              end 
         end       
    end 
    if saveFlag
        save(fileSave,'numSpikesST','numSpikesBL','powerST','powerBL','freqVals','electrodeList','x');
    end
end
end






