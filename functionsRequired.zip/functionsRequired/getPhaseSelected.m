
% this fnxn takes an image segment inImage (n x n pixels)
% degppix degrees per pixel, degIm, extent of the image
% the SF (cpd) and ori (radians) that fits the image (or that you have chosen)
% returns the fourier spatial phase at that SF 
% have tested with a dummy grating and its ohase shofting versions-010920

function [ph] = getPhaseSelected(inImage, degppix, degIm, SF, Ori)

res = size(inImage,1);

[x,y,Fx,Fy]= getXYaxes(res,degppix,degIm);

[~,ImR,ImI]= getImageDFT(inImage);

% select phase at the SF Ori chosen
% the ImI is a 2D array with phase values. We need to read the correct one
% For an oriented grating, the x-axis SF is SF*cos(Ori) and y-axis as
% SF*sin(Ori). If grating is tilted, more (white/black) pixels will fall on the x-axis 
% and so new SF will be lower. We need to read the phase value at these new SFs

% The - sign in eff_Fx. Tried several combinations of cosOri & sinOri. This
% one gave the correct phases of predetermined gratings 

eff_Fx = -SF*cos(Ori);
eff_Fy = SF*sin(Ori);
indx = getClosestInd(Fx,eff_Fx);
indy = getClosestInd(Fy,eff_Fy);
ph   = ImI(indy,indx);  

end

function [x,y,Fx,Fy]= getXYaxes(res,degppix,degIm)
% get the x,y axes of square image in space & in f domain:

% spatial domain axes: degrees
x = degppix * (0:res-1);
y = x;
% image pixels per degree - sampling freq
Fs = 1/degppix;

% freq domain axes: cycles/degree
dFx = 1/degIm;
Fx = -Fs/2 : dFx : Fs/2-dFx;
Fy = Fx;

end

function [ImageDFT,ImR,ImI]= getImageDFT(Image2D)

ImageDFT = fftshift(fft2(Image2D));            % 2D FFT
ImR = abs(ImageDFT);
ImI = angle(ImageDFT);

end

function [radare, radSpec, radPh] = getRadAvg(fft2d, Fx, Fy)

% modified from getImageSFSpectra> getRadAvg of Image project 


temp = diff(Fx); dFx = temp(1);
temp = diff(Fy); dFy = temp(1);
[hIm,wIm] = size(fft2d);
imgamp = abs(fft2d);    %   imgfp = abs(fft2d);
imgph  = angle(fft2d);

% Compute radially average power spectrum. My method evolved from others.
% see these: 
% Image analyst's answer: https://nl.mathworks.com/matlabcentral/answers/340538-how-to-average-the-2d-spectrum-of-an-image-from-fft2-to-get-1d-spectrum
% https://nl.mathworks.com/matlabcentral/fileexchange/23636-radially-averaged-power-spectrum-of-2d-real-valued-matrix
% https://dsp.stackexchange.com/questions/37957/power-spectrum-of-2d-image-result-interpretation
% https://mathematica.stackexchange.com/questions/88168/averaging-over-a-circle-from-fft-to-plot-the-amplitude-vs-wavelength
% Our PSD is not square. Moving 1 point in X direction may not be equal to moving 1 point in Y direction.
% dFx ~=dFy, so equidistant points will form an ellipse, not circle, around the center pixel
% now calculate the radius from 0,0 at each pixel 

[X, Y] = meshgrid(-wIm/2:wIm/2-1, -hIm/2:hIm/2-1);    
rho = nan(size(imgamp));
for rows=1:size(imgamp,1)
    for cols=1:size(imgamp,2)
        rho(rows,cols)= sqrt( (X(rows,cols)*dFx)^2 + (Y(rows,cols)*dFy)^2 );
    end
end
% now make a vector of radii.
% make bins of radii sizes, within each bin you will combine & avg pixels
% if dFx==dFy, you could just use either as bin width
maxrho  = max(max(rho));
stepsize= max(dFx,dFy);                % bigger of the two 
radare  = 0:stepsize:maxrho;           % outer edges, same unit as dFx, dFy, Fx, Fy


i = cell(size(radare));                % will have pixel inds at each radius
r = 1;
i{1} = find(rho <=radare(r));
for r = 2:length(radare)
    i{r} = find(rho <=radare(r) & rho >radare(r-1));
end

radSpec = zeros(size(radare));
for r = 1:length(radare)
    radSpec(r) = nanmean( imgamp( i{r} ) );
end

radPh = zeros(size(radare));
for r = 1:length(radare)
    radPh(r) = circ_mean( imgph( i{r} ) );
end

% figure; 
% plot(radare,log10(radSpec))

end

