% function to get the gamma responses to the differnt parameters of
% gratings.
% input: monkeyname
% uses all available electrodes
% accesses the protocols of the electrode for
% SFOri, SizeOri and ConTF/ConOri
% computes the gamma power for those cases, and gives a matrix with gamma
% power in 2 variables of the following
% SF x Size x Ori x Con
% 090520: updated to gamma = 35-70
% 241120: commented the getResponses fnxn. Use the separate function instead. 
% updated: saves the dGamma matrix for all Size Ori electrodes
% then saves for all highRMS electrodes, using an averaged SizeOri data 


function [delGamma,expDate,protocolName,protocolTypes,electrodes] = getGammaPowerGratings(monkeyName)

rootPath = gammaModelPath_st();
dataDir  = fullfile(rootPath, 'Data');
folderSourceString = '/Volumes/SIDSANDISK/fss/';
gridType = 'Microelectrode';
useNotchData = 0;
tBL = [-0.25 0];
tST = [0.25 0.5];
numTapers = 3;
fBands = {[8 12] [35 70] [80 148] [150 250]};  % 1st has to be alpha
fBad   = []; % [48:52 98:102 148 152];
fBandG = [35 70];    % this is the gamma range to be used

methodFlag = 0; % 0= MT & dB change in gamma, 1= Gaussian gamma fit like Hermes etal.

[expDates, protocolNames, protocolTypes, electrodes, elecType] = getProtocolInfoGratings(monkeyName,gridType,folderSourceString);

% for each electrode, pick out the protocols.
for el= 1:length(electrodes)
    elecis = electrodes(el);
    disp(['Doing electrode ', num2str(elecis)]);
    saveFileIs = fullfile(dataDir,'derivatives','dGamma',['dGamma_',num2str(fBandG(1)),'_',num2str(fBandG(2)),'_tST_',num2str(tST(1)*1000),'_',num2str(tST(2)*1000),'_Tapers',num2str(numTapers),'_',...
        monkeyName,'_elec',num2str(elecis),'_',protocolTypes{1},'_',protocolTypes{2},expDates{2}{el},protocolNames{2}{el},'_',protocolTypes{3},'_method',num2str(methodFlag),'_notch',num2str(useNotchData),'.mat']);
    if ~exist(saveFileIs,'file')
        for p = 1:length(protocolTypes)  
            expDate{p} = expDates{p}{el};
            protocolName{p} = protocolNames{p}{el};

            [delGamma{p},parameterCombinations{p}]= getPwrSpectra(gridType,folderSourceString,monkeyName,expDate{p},protocolName{p},protocolTypes{p},tST,tBL,numTapers,fBands,fBad,fBandG,elecis,dataDir,methodFlag,useNotchData);
        end 
        % save for each electrode:
        save(saveFileIs,'delGamma', 'expDate', 'protocolName','protocolTypes','parameterCombinations')
    else
        load(saveFileIs);
    end
end

% Now since Size Ori is not available for all electrodes & for some it is
% on 2 sessions, we will use an average size ori for all elecs. 
% The gamma vs size trend and roughly, the magnitude of ST/BL is quite similar.
% So average is a good representation. 
% I have made sure that the parameterCombinations and the sizes used in all
% sessions are same. 

% first get the average SizeOri of electrodes you have

ind1 = find(strcmp(protocolTypes,'SizeOri')); % is the 2nd one. still for check
ind2 = find(~strcmp(protocolTypes,'SizeOri'));
dGuse = [];
lfpels  = (strcmp(elecType,'LFP'));
electrodes = electrodes(lfpels);
expDates   = cellfun(@(x) x(lfpels), expDates,'un',0);  
protocolNames=cellfun(@(x) x(lfpels), protocolNames,'un',0);
for el= 1:length(electrodes)
    elecis = electrodes(el);
    saveFileIs = fullfile(dataDir,'derivatives','dGamma',['dGamma_',num2str(fBandG(1)),'_',num2str(fBandG(2)),'_tST_',num2str(tST(1)*1000),'_',num2str(tST(2)*1000),'_Tapers',num2str(numTapers),'_',...
        monkeyName,'_elec',num2str(elecis),'_',protocolTypes{1},'_',protocolTypes{2},expDates{2}{el},protocolNames{2}{el},'_',protocolTypes{3},'_method',num2str(methodFlag),'_notch',num2str(useNotchData),'.mat']);
    load(saveFileIs);
    dGuse= cat(1,dGuse,delGamma{ind1});
    pCuse = parameterCombinations{ind1};  % same except azi ele
end
mean_dG = mean(dGuse,1);
pCuse = parameterCombinations{ind1};
% Next get high RMS elecs.
[~,~,LFPElectrodeList,~,~] = getRFdetails({monkeyName},dataDir);
LFPElectrodeList = LFPElectrodeList{1};

% compute delta gamma for each electrode
for el= 1:length(LFPElectrodeList)
    clear delGamma parameterCombinations;
    elecis = LFPElectrodeList(el);
    disp(['Doing electrode ', num2str(elecis)]);
    saveFileIs = fullfile(dataDir,'derivatives','dGamma',['dGamma_',num2str(fBandG(1)),'_',num2str(fBandG(2)),'_tST_',num2str(tST(1)*1000),'_',num2str(tST(2)*1000),'_Tapers',num2str(numTapers),'_',...
        monkeyName,'_elec',num2str(elecis),'_',protocolTypes{1},'_',protocolTypes{2},'_',protocolTypes{3},'_method',num2str(methodFlag),'_notch',num2str(useNotchData),'.mat']);
    if ~exist(saveFileIs,'file')
        for p = ind2  % for full screen protocols
            expDate{p}      = expDates{p}{1};  % same for all elecs
            protocolName{p} = protocolNames{p}{1};
            [delGamma{p},parameterCombinations{p}]= getPwrSpectra(gridType,folderSourceString,monkeyName,expDate{p},protocolName{p},protocolTypes{p},tST,tBL,numTapers,fBands,fBad,fBandG,elecis,dataDir,methodFlag,useNotchData);
        end
        p = ind1; % for Size Ori
        expDate{p}      ='average';  protocolName{p} ='average';
        delGamma{p}  = mean_dG;   parameterCombinations{p} = pCuse;
        
        % finally save for each of highRMS electrodes:
        save(saveFileIs,'delGamma', 'expDate', 'protocolName','protocolTypes','parameterCombinations')
    else
        load(saveFileIs);
    end
end


end

function [delGammaOut,parameterCombinations]= getPwrSpectra(gridType,folderSourceString,subjectName,expDate,protocolName,typeProtocol,tST,tBL,numTapers,fBands,fBad,fband,elecis,dataDir,methodFlag,useNotchData)
if ~exist('methodFlag','var'),     methodFlag=0; end
if ~exist('useNotchData','var'), useNotchData=0; end

dataDir2= fullfile(dataDir,'derivatives','Spectra');

savefileis = fullfile(dataDir2,['PowerSp_',subjectName,expDate,protocolName,'_st_',num2str(tST(1)*1000),'_',num2str(tST(2)*1000),...
        '_bl_',num2str(tBL(1)*1000),'_',num2str(tBL(2)*1000),'_method',num2str(methodFlag),'_notch',num2str(useNotchData),'.mat']);
    
if exist(savefileis,'file')
    disp(['Loading power spectrum file ', expDate,protocolName]);
    load(savefileis); 
    
else
    [pwrLfpST,pwrLfpBL,freqVals,pwrEcogST,pwrEcogBL,LFPElectrodes,EcogElectrodes,parameterCombinations] = getResponses(gridType,folderSourceString,subjectName,expDate,protocolName,typeProtocol,tBL,tST,numTapers,[],[],dataDir2,useNotchData);

    if methodFlag==0
        
        for el = 1:length(LFPElectrodes)  % for each electrode, get stim x stim x fbands
            [temp1,temp2,temp3] = getPowerChanges(pwrLfpST(el,:,:),pwrLfpBL(el,:,:),freqVals,fBands,fBad);
            logDelPwrLfpBand(el,:,:,:)=temp1; stPwrLfp(el,:,:,:)=temp2; blPwrLfp(el,:,:,:)=temp3; 
        end                                
        for el = 1:length(EcogElectrodes)
             [temp1,temp2,temp3] = getPowerChanges(pwrEcogST(el,:,:),pwrEcogBL(el,:,:),freqVals,fBands,fBad);
             logDelPwrEcogBand(el,:,:,:)=temp1; stPwrEcog(el,:,:,:)=temp2; blPwrEcog(el,:,:,:)=temp3;
        end                      % end electrode
        save(savefileis,'logDelPwrLfpBand','logDelPwrEcogBand','stPwrLfp','stPwrEcog','blPwrLfp','blPwrEcog','fBands','fBad','numTapers','freqVals','tBL','tST','LFPElectrodes','EcogElectrodes','typeProtocol','parameterCombinations');

    elseif methodFlag==1
        
        nr_boots = 200;     % nr of bootstrap for resampling per stimulus
        f_use4fit = setdiff([28:200], fBad);     % freqs to use in fitting
        alphBand  = fBands{1};
        for el = 1:length(LFPElectrodes)  % for each electrode
            [resamp_parmsLfp{el}(:,:,:),fitSTLfp{el}(:,:,:),resamp_parmsDetail] = getPowerFits(pwrLfpST(el,:),pwrLfpBL(el,:), freqVals,f_use4fit,alphBand,nr_boots);
        end        
        for el = 1:length(EcogElectrodes)
            [resamp_parmsEcog{el}(:,:,:),fitSTEcog{el}(:,:,:),resamp_parmsDetail]= getPowerFits(pwrEcogST(el,:),pwrEcogBL(el,:),freqVals,f_use4fit,alphBand,nr_boots);
        end                      % end electrode
        save(savefileis,'resamp_parmsLfp','resamp_parmsEcog','fitSTLfp','fitSTEcog','f_use4fit','alphBand','numTapers','LFPElectrodes','EcogElectrodes','resamp_parmsDetail','freqVals','tBL','tST','typeProtocol','parameterCombinations');   

    end     % end if method flag
end

%assign gamma band power
fbind = find(cell2mat(cellfun(@(x) isequal(x,fband), fBands,'un',0))==1);

if methodFlag == 0
    electrodeList= cat(1,LFPElectrodes,EcogElectrodes);
    
    if ~isempty(fbind)   % assign band power. 
        delGammaLfp  = (10.^squeeze((logDelPwrLfpBand(:,:,:,fbind))));   
        delGammaEcog = (10.^squeeze((logDelPwrEcogBand(:,:,:,fbind))));  
        delGamma     = cat(1,delGammaLfp,delGammaEcog);
        
    else  
        meanPwrBLall = cat(1,blPwrLfp,blPwrEcog);
        meanPwrST    = cat(1,stPwrLfp,stPwrEcog);
        [~,numStimuli1,numStimuli2,~]  = size(stPwrLfp); 
        stBandPwr    = zeros(length(electrodeList),numStimuli1,numStimuli2);
        blBandPwr    = zeros(length(electrodeList),1);
        [~,Bads]     = intersect(freqVals,fBad);
        f_inds       = freqVals>=fband(1) & freqVals<=fband(2);
        f_inds(Bads) = 0;
        for elec = 1:length(electrodeList)
            blBandPwr(elec) = sum(squeeze(meanPwrBLall(elec,f_inds)));
            for sPos = 1:numStimuli1  
                for oPos = 1:numStimuli2 
                    stBandPwr(elec,sPos,oPos) = sum(squeeze(meanPwrST(elec,sPos,oPos,f_inds))); 
                    delGamma(elec,sPos,oPos)= (stBandPwr(elec,sPos,oPos))./(blBandPwr(elec));
                end  
            end 
        end 
    end 
    e_is = find(electrodeList==elecis);
    delGammaOut  = delGamma(e_is,:,:);
        
elseif  methodFlag == 1
    electrodeList= cat(1,LFPElectrodes,EcogElectrodes);
    resamp_parms = cat(1,resamp_parmsLfp(:), resamp_parmsEcog(:));      % stim x bootstrap x 7
        % Gamma power signal change per stimulus:
    e_is = find(electrodeList==elecis);
    delGammaOut  = (10.^(resamp_parms{e_is}(:,:,3)./resamp_parms{e_is}(:,:,5))-1); % Actual gamma amplitude is parm3/5 width./amplitude
        
end 

end


function [logPwrChangeOut,meanPwrSTOut,meanPwrBLall,stBandPwrOut,blBandPwr] = getPowerChanges(powerST,powerBL,freqVals,fBands,fBad)
% function to get change in power in given ranges

    [numElecs,numStimuli1,numStimuli2] = size(powerBL);
    
    meanPwrBL = zeros([numElecs,numStimuli1,numStimuli2,length(freqVals)]);
    meanPwrST = zeros([numElecs,numStimuli1,numStimuli2,length(freqVals)]);
    clear meanPwrBLall   
    for elec = 1:numElecs
        for sPos = 1:numStimuli1  
        for oPos = 1:numStimuli2                                     % for each stimulus
            allLFPDataBL = (powerBL{elec,sPos,oPos});
            allLFPDataST = (powerST{elec,sPos,oPos});
            meanPwrBL(elec,sPos,oPos,:) = mean(allLFPDataBL,2);          % mean across trials
            meanPwrST(elec,sPos,oPos,:) = mean(allLFPDataST,2);     
        end
        end% end stimulus
        meanPwrBLall(elec,:) = squeeze(nanmean(nanmean(meanPwrBL(elec,:,:,:),3),2));        % get average baseline across all stimuli
    end           

   % get gamma & BB power
   logPwrChange = zeros(numElecs,numStimuli1,numStimuli2,length(fBands));
   stBandPwr    = zeros(numElecs,numStimuli1,numStimuli2,length(fBands));
   blBandPwr    = zeros(numElecs,length(fBands));
   [~,Bads] = intersect(freqVals,fBad);
   for ii=1:length(fBands)
       fBand = fBands{ii};
       f_inds = freqVals>=fBand(1) & freqVals<=fBand(2);
       f_inds(Bads) = 0;
       for elec = 1:numElecs
           blBandPwr(elec,ii) = sum(squeeze(meanPwrBLall(elec,f_inds)));
           for sPos = 1:numStimuli1  
           for oPos = 1:numStimuli2 
              stBandPwr(elec,sPos,oPos,ii) = sum(squeeze(meanPwrST(elec,sPos,oPos,f_inds))); 
              logPwrChange(elec,sPos,oPos,ii) = log10(stBandPwr(elec,sPos,oPos,ii)) - log10(blBandPwr(elec,ii));
           end 
           end
       end 
   end
   
   if numElecs==1
        logPwrChangeOut(:,:,:)= logPwrChange(1,:,:,:);
        meanPwrSTOut(:,:,:)   = meanPwrST(1,:,:,:);
        meanPwrBLall          = meanPwrBLall(1,:,:);
        stBandPwrOut(:,:,:)   = stBandPwr(1,:,:,:);
        blBandPwr             = blBandPwr(1,:,:);
   else
       logPwrChangeOut= logPwrChange;
       meanPwrSTOut   = meanPwrST;
       meanPwrBLall   = meanPwrBLall;
       stBandPwrOut   = stBandPwr;
       blBandPwr      = blBandPwr;
   end

end

function [resamp_parms,fit_is,resamp_parmsDetail] = getPowerFits(powerST,powerBL,freqVals,f_use4fit,alphBand,nr_boots)
% CHECK THIS FUNTCION FOR COMPATIBILITY WITH THIS OVERALL CODE 
% STK, 150420


[numElecs,numStimuli,~] = size(powerBL);
f_alpha = find(freqVals>=alphBand(1) & freqVals<=alphBand(2));

% define output:
resamp_parms = NaN(numStimuli,nr_boots,7);
fit_is       = NaN(numStimuli,nr_boots,length(freqVals));

meanPwrBL = zeros([numStimuli,length(freqVals)]);
clear meanPwrBLall   
    for oPos = 1:numStimuli                                     % for each stimulus
        allLFPDataBL = (powerBL{1,oPos});
        meanPwrBL(oPos,:) = mean(allLFPDataBL,2);          % mean across trials
    end              % end stimulus
    data_BL = mean(meanPwrBL,1);         % for the baseline, do not resample, average across all trials
            
for oPos = 1:numStimuli
    disp(['fitting stimulus ' int2str(oPos) ' of ' int2str(numStimuli)]);
    for ii = 1:nr_boots
        % get stimulus data
        data_ST = powerST{1,oPos};
        data_ST = data_ST';    % trials x freq
        
        % from stimulus data, random sample with replacement
        trial_set = randsample(size(data_ST,1),size(data_ST,1),true);

        % average across resampled trials
        data_ST = mean(data_ST(trial_set,:),1);

        % do the fitting
        [out_exp,bb_amp,gamma_amp,gamma_freq,gamma_width,fit_f2] = ecog_fitgamma(freqVals',f_use4fit,data_BL,data_ST);
        resamp_parms(oPos,ii,1) = out_exp(1); % this is the slope used in all cases
        resamp_parms(oPos,ii,2) = bb_amp;
        resamp_parms(oPos,ii,3) = gamma_amp;
        resamp_parms(oPos,ii,4) = gamma_freq;
        resamp_parms(oPos,ii,5) = gamma_width;
        resamp_parms(oPos,ii,6) = out_exp(2); % this is the baseline intercept
        %  alpha change
        resamp_parms(oPos,ii,7) = mean(log10(data_ST(f_alpha)) - log10(data_BL(f_alpha)));
        fit_is(oPos,ii,:) = fit_f2;
    end
end
fit_is = squeeze(mean(fit_is,2));  
resamp_parmsDetail = {'BL Slope','Log10 BB Amp','Log10 Gamma Gaussian Amp over BB','Gamma Center Freq','Gamma Gaussian Width','BL intercept','Log10 Alpha Change'};
end

% function [pwrST,pwrBL,freqVals,pwrEcogST,pwrEcogBL,LFPElectrodeList,EcogElectrodeList,parameterCombinations]= getResponses(gridType,folderSourceString,subjectName,expDate,protocolName,typeProtocol,tBL,tST,numTapers,dataDir,useNotchData)
% 
% if ~exist('useNotchData','var'), useNotchData=0; end
% 
% if ~exist('numTapers','var')||isempty(numTapers), numTapers = 3; end
% estFlag=1;            % for MT 
% 
% load(fullfile(folderSourceString,'data',subjectName,gridType,expDate,protocolName,[subjectName,expDate,protocolName,'ElectrodeList.mat']));   % load electrodes
% parameterCombinations=load(fullfile(folderSourceString,'data',subjectName,gridType,expDate,protocolName,'extractedData','parameterCombinations.mat')); % ParameterCombinations
% % some updates on parameter combinations
% indsz = parameterCombinations.sValsUnique<0 | parameterCombinations.sValsUnique>11 ; % for sizes that are FS 
% parameterCombinations.sValsUnique(indsz) = 11.5; % Full Screen
% [~,indor] = intersect(parameterCombinations.oValsUnique,[22 67 112 157]); % for oris at gap of 22.5 
% parameterCombinations.oValsUnique(indor) = parameterCombinations.oValsUnique(indor)+0.5;
% 
% if strcmp(typeProtocol, 'Ori') || strcmp(typeProtocol, 'SFOri')
%     % returns in terms of elec x sf x ori
%     if ~isempty(LFPElectrodeList)
%         [~,~,pwrST,pwrBL,freqVals]  = getFRandPowerSFOri2(subjectName,gridType,folderSourceString,expDate,protocolName, LFPElectrodeList ,tBL,tST,estFlag,numTapers,1,dataDir,useNotchData);
%     else
%         pwrST= {[]}; pwrBL= {[]};
%     end
%     if ~isempty(EcogElectrodeList)
%         [~,~,pwrEcogST,pwrEcogBL,freqVals] = getFRandPowerSFOri2(subjectName,gridType,folderSourceString,expDate,protocolName,EcogElectrodeList ,tBL,tST,estFlag,numTapers,1,dataDir,useNotchData);
%     else
%         pwrEcogST={[]}; pwrEcogBL={[]};
%     end
%     
% elseif strcmp(typeProtocol, 'SizeOri')
%     % returns in terms of elec x size x ori
%     if ~isempty(LFPElectrodeList)
%         [~,~,pwrST,pwrBL,freqVals]  = getFRandPowerSizeOri2(subjectName,gridType,folderSourceString,expDate,protocolName,LFPElectrodeList , tBL,tST,estFlag,numTapers,1,dataDir,useNotchData);
%     else
%         pwrST= {[]}; pwrBL= {[]};
%     end
%     if ~isempty(EcogElectrodeList)
%         [~,~,pwrEcogST,pwrEcogBL,freqVals] = getFRandPowerSizeOri2(subjectName,gridType,folderSourceString,expDate,protocolName,EcogElectrodeList ,tBL,tST,estFlag,numTapers,1,dataDir,useNotchData);
%     else
%         pwrEcogST={[]}; pwrEcogBL={[]};
%     end  
% 
% elseif  strcmp(typeProtocol, 'ConTF') || strcmp(typeProtocol, 'ConOri')
%     % returns in terms of elec x size x con x ori for static case
%     chooseS = parameterCombinations.sValsUnique==11.5;  % full screen
%     parameterCombinations.sValsUnique = parameterCombinations.sValsUnique(chooseS);
%     if ~isempty(LFPElectrodeList)
%         [~,~,pwrST,pwrBL,freqVals]  = getFRandPowerConOri2(subjectName,gridType,folderSourceString,expDate,protocolName,LFPElectrodeList , tBL,tST,estFlag,numTapers,1,dataDir,useNotchData);
%         if ~iscell(pwrST),
%             pwrST= squeeze(pwrST(:,chooseS,:,:)); pwrBL= squeeze(pwrBL(:,chooseS,:,:));
%         else
%             pwrST= cellfun(@(x) squeeze(x(:,chooseS,:,:)), pwrST,'un',0); pwrBL= cellfun(@(x) squeeze(x(:,chooseS,:,:)), pwrBL,'un',0);
%         end
%     else
%         pwrST= {[]}; pwrBL= {[]};
%     end
%     if ~isempty(EcogElectrodeList)
%         [~,~,pwrEcogST,pwrEcogBL,freqVals] = getFRandPowerConOri2(subjectName,gridType,folderSourceString,expDate,protocolName,EcogElectrodeList ,tBL,tST,estFlag,numTapers,1,dataDir,useNotchData);
%         if ~iscell(pwrEcogST)
%             pwrEcogST= squeeze(pwrEcogST(:,chooseS,:,:)); pwrEcogBL= squeeze(pwrEcogBL(:,chooseS,:,:));
%         else
%             pwrEcogST= cellfun(@(x) squeeze(x(:,chooseS,:,:)), pwrEcogST,'un',0); pwrEcogBL= cellfun(@(x) squeeze(x(:,chooseS,:,:)), pwrEcogBL,'un',0);
%         end
%     else
%         pwrEcogST={[]}; pwrEcogBL={[]};
%     end 
%     
% end
% 
% if iscell(pwrST) && length(pwrST)==1,                 % if values are as 1x1 cells containing cells, unwrap them
%    pwrST     = pwrST{1};      pwrBL     = pwrBL{1}; 
%    pwrEcogST = pwrEcogST{1};  pwrEcogBL = pwrEcogBL{1}; 
% end   
% 
%   
% end
