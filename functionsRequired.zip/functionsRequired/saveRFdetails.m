% code to get RF locations of all electrodes:
% RFs are given in degree visual angle azimuth & elevation from center of screen
% convert into pixel values
% use the image pixel size and degree span.
% this code is written for the precoessed square images obtained from the
% screenshots - after preProcessingImageSS.m

ImgDvaSize   = 25.0088;     % Get from preProcessingImageSS
ImgPixelSize = 270;    % Get from preProcessingImageSS
DegPerPix    = 0.0926;   % Get from preProcessingImageSS
imgcenter    = ImgPixelSize/2;

subjectNames= {'alpaH','kesariH'};

for m = 1:2
    subjectName  = subjectNames{m};
    
    if strcmp(subjectName,'kesariH')
         load(['F:\Programs\DataMAP\ReceptiveFieldData\kesariHMicroelectrodeRFData_Two.mat']);
%          load(fullfile('/Users','sidrattasawoor','Documents','SidratAcademics','PhDIISc','LABWORK','ProjectCodes','Programs','DataMAP','ReceptiveFieldData','kesariHMicroelectrodeRFData_Two.mat'),'rfStats');
         B = load(['F:\Programs\DataMAP\ReceptiveFieldData\kesariHMicroelectrodeRFData.mat']);
%          B = load(fullfile('/Users','sidrattasawoor','Documents','SidratAcademics','PhDIISc','LABWORK','ProjectCodes','Programs','DataMAP','ReceptiveFieldData','kesariHMicroelectrodeRFData.mat'));
         LFPElectrodes = highRMSElectrodes(highRMSElectrodes<82); LFPElectrodes=LFPElectrodes(:);
         EcogElectrodes = [85 86 88 89]';
         for i=1:length(EcogElectrodes)
             rfStats(EcogElectrodes(i)).meanAzi = B.rfStats(EcogElectrodes(i)).meanAzi;
             rfStats(EcogElectrodes(i)).meanEle = B.rfStats(EcogElectrodes(i)).meanEle;
             rfStats(EcogElectrodes(i)).rfSizeAzi = B.rfStats(EcogElectrodes(i)).rfSizeAzi;
             rfStats(EcogElectrodes(i)).rfSizeEle = B.rfStats(EcogElectrodes(i)).rfSizeEle;
             rfStats(EcogElectrodes(i)).params = B.rfStats(EcogElectrodes(i)).params;
         end  
    elseif strcmp(subjectName,'alpaH')
        load(['F:\Programs\DataMAP\ReceptiveFieldData\',subjectName,'MicroelectrodeRFData.mat']);  % load RF data
%         load(fullfile('/Users','sidrattasawoor','Documents','SidratAcademics','PhDIISc','LABWORK','ProjectCodes','Programs','DataMAP','ReceptiveFieldData','alpaHMicroelectrodeRFData.mat'),'rfStats');
        B = load(['F:\Programs\DataMAP\ReceptiveFieldData\',subjectName,'EcogRFParams.mat']);
%         B = load(fullfile('/Users','sidrattasawoor','Documents','SidratAcademics','PhDIISc','LABWORK','ProjectCodes','Programs','DataMAP','ReceptiveFieldData','alpaHEcogRFParams.mat'));
        rfStats = rfStats(1:81);      % only microelectrode        
        LFPElectrodes = highRMSElectrodes(highRMSElectrodes<82); LFPElectrodes=LFPElectrodes(:);
        EcogElectrodes = [82 85 86 88 89]';
        stats = cell2mat(B.paramsMinScaled(EcogElectrodes,6)); clear B;    % 6th column - time window - checked with Agrita
        for i=1:length(EcogElectrodes)
            rfStats(EcogElectrodes(i)).meanAzi = stats(i,1);
            rfStats(EcogElectrodes(i)).meanEle = stats(i,2);
            rfStats(EcogElectrodes(i)).rfSizeAzi = stats(i,3);
            rfStats(EcogElectrodes(i)).rfSizeEle = stats(i,4);
            rfStats(EcogElectrodes(i)).params = stats(i,:);
        end  
    end  
    rfStatsDeg{m}       = rfStats;
    LFPElectrodeList{m} = LFPElectrodes;
    EcogElectrodeList{m}= EcogElectrodes;
    
    for el = 1:length(LFPElectrodes) 
        azi = imgcenter + rfStats(LFPElectrodes(el)).meanAzi/ DegPerPix;    % convert to pixel
        ele = imgcenter - rfStats(LFPElectrodes(el)).meanEle/ DegPerPix;
        sizeazi= rfStats(LFPElectrodes(el)).rfSizeAzi/ DegPerPix;
        sizeele= rfStats(LFPElectrodes(el)).rfSizeEle/ DegPerPix;
        rfStatsP(LFPElectrodes(el)).meanAzi = azi;
        rfStatsP(LFPElectrodes(el)).meanEle = ele;
        rfStatsP(LFPElectrodes(el)).rfSizeAzi = sizeazi;
        rfStatsP(LFPElectrodes(el)).rfSizeEle = sizeele;
    end
    
    for el = 1:length(EcogElectrodes) 
        azi = imgcenter + rfStats(EcogElectrodes(el)).meanAzi/ DegPerPix;    % convert to pixel
        ele = imgcenter - rfStats(EcogElectrodes(el)).meanEle/ DegPerPix;
        sizeazi= rfStats(EcogElectrodes(el)).rfSizeAzi/ DegPerPix;
        sizeele= rfStats(EcogElectrodes(el)).rfSizeEle/ DegPerPix;
        rfStatsP(EcogElectrodes(el)).meanAzi = (azi);
        rfStatsP(EcogElectrodes(el)).meanEle = (ele);
        rfStatsP(EcogElectrodes(el)).rfSizeAzi = (sizeazi);
        rfStatsP(EcogElectrodes(el)).rfSizeEle = (sizeele);
    end
    rfStatsPix{m} = rfStatsP;
%         x1= round(imgcenter+(azi-sizeazi)); x2 = round(imgcenter+(azi+sizeazi));
%         y1= round(imgcenter-(ele-sizeele)); y2 = round(imgcenter-(ele+sizeele));
end
readme = 'rfStatsDeg in dva wrt to screen center. rfStatsPix actual pixel values in processed image.';

folderName= fullfile('F:','ProjectWork','ProjectII_HSV','Models','OVModelRelated','Data');
filename  = fullfile(folderName,'RFDetails.mat');
save(filename,'rfStatsDeg','rfStatsPix','LFPElectrodeList','EcogElectrodeList','ImgPixelSize','ImgDvaSize','DegPerPix','subjectNames','readme');


