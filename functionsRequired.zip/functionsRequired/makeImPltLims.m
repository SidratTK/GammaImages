
function [choosecol,chooserow]= makeImPltLims(azipix,elepix,widthPatch,degppix,implots,imdata)
     
twidthPix = (1/2)*widthPatch/degppix;
choosecol = [ceil(azipix - twidthPix) : ceil(azipix + twidthPix)];
chooserow = [ceil(elepix - twidthPix) : ceil(elepix + twidthPix)];
axes(implots);
% imagesc(imdata(chooserow,choosecol,:));
imagesc(imdata);
xlim([min(choosecol) max(choosecol)]);
ylim([min(chooserow) max(chooserow)]);

end
    
