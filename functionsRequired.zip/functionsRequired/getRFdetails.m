

function [rfStatsDeg,rfStatsPix,LFPElectrodeList,EcogElectrodeList,subjectNames] = getRFdetails(subjectNamesA,folderName)

filename  = fullfile(folderName,'RFDetails.mat');
load(filename,'rfStatsDeg','rfStatsPix','LFPElectrodeList','EcogElectrodeList','ImgPixelSize','ImgDvaSize','DegPerPix','subjectNames','readme');
if isempty(intersect(subjectNames,subjectNamesA))
    disp('details not saved for given subjects. Use saveRFdetails.m to save them first')
else
    disp('Subjects available:')
    [a,ind]= intersect(subjectNames,subjectNamesA);
    disp(a);
    rfStatsDeg = rfStatsDeg(ind); 
    rfStatsPix = rfStatsPix(ind);
    LFPElectrodeList =  LFPElectrodeList(ind);
    EcogElectrodeList = EcogElectrodeList(ind);
    subjectNames = subjectNames(ind);
    
end

end