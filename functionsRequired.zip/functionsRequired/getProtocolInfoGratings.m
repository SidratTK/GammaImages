% function to return details of protocols, electrode wise
% updated 290420 to get LFP electrodes as well
% updated 101220 to include datadir 

function [expDates, protocolNames, protocolTypes, electrodes, elecType] = getProtocolInfoGratings(monkeyName,gridType,folderSourceString,datadir)
if ~exist('gridType','var'),           gridType = 'Microelectrode';                      end
if ~exist('folderSourceString','var'), folderSourceString = '/Volumes/SIDSANDISK2/fss/'; end
if ~exist('datadir','var'),            datadir = fullfile(gammaModelPath_st(), 'Data');  end

protocolTypes = {'SFOri', 'SizeOri', 'ConOri'};
expDates      = cell(length(protocolTypes),1);
protocolNames = cell(length(protocolTypes),1);

if strcmp(monkeyName,'alpaH')
    electrodes =       [82      85      86      88     89]; 
    elecType =         {'ECoG', 'ECoG', 'ECoG', 'ECoG', 'ECoG'};
    expDates{1} =      {'210817' ,'210817' ,'210817' ,'210817' ,'210817' };  % SFOri FullScreen
    protocolNames{1} = {'GRF_002','GRF_002','GRF_002','GRF_002', 'GRF_002'};
    expDates{2} =      {'130917' ,'080917' ,'080917' ,'170817' ,'260817'};    % size ori electrode wise
    protocolNames{2} = {'GRF_001','GRF_001','GRF_002','GRF_005','GRF_002'};
    expDates{3} =      {'290817' ,'290817' ,'290817' ,'290817' ,'290817'}; % conTFOri
    protocolNames{3} = {'GRF_001','GRF_001','GRF_001','GRF_001','GRF_001'};
    
elseif strcmp(monkeyName,'kesariH')
    electrodes =       [85         86        88        89]; 
    elecType =         {'ECoG',    'ECoG',   'ECoG',   'ECoG'};
    expDates{1} =      {'270218' ,'270218' ,'270218' ,'270218'};
    protocolNames{1} = {'GRF_001','GRF_001','GRF_001','GRF_001'};
    expDates{2} =      {'271217' ,'030118' ,'060118' ,'070118'};   % size ori electrode wise
    protocolNames{2} = {'GRF_002','GRF_002','GRF_002','GRF_001'};
%     expDates{3} =      {'010318' ,'010318' ,'010318' ,'010318'};  % conTF
    expDates{3} =      {'240118' ,'240118' ,'240118' ,'240118'};  % conOri
    protocolNames{3} = {'GRF_002','GRF_002','GRF_002','GRF_002'};
end

% LFP elecs for size ori:
filename = fullfile(datadir,['SizeOri_LfpElecs_',monkeyName,'.mat']);
if ~exist(filename,'file')
    [elecListAll,expDateAll,protocolNameAll] = getLfpElectrodesSizeOri(monkeyName,gridType,folderSourceString);
    save(filename,'elecListAll','expDateAll','protocolNameAll');
else
    load(filename);
end

electrodes = cat(2, electrodes, elecListAll);
elecType   = cat(2, elecType  , repmat({'LFP'},[1 length(elecListAll)]));
expDates{1}      = cat(2, expDates{1},      repmat(expDates{1}(1),      [1 length(elecListAll)]));
protocolNames{1} = cat(2, protocolNames{1}, repmat(protocolNames{1}(1), [1 length(elecListAll)]));
expDates{2}      = cat(2, expDates{2},      expDateAll);
protocolNames{2} = cat(2, protocolNames{2}, protocolNameAll);
expDates{3}      = cat(2, expDates{3},      repmat(expDates{3}(1),      [1 length(elecListAll)]));
protocolNames{3} = cat(2, protocolNames{3}, repmat(protocolNames{3}(1), [1 length(elecListAll)]));


end
