% function to send back responses 
% made separate function - 241120 STK.
% also included the grating protocols and image protocols in same code. 
% 261120: option to drop size<0.1. since only some protocols have it


function [pwrST,pwrBL,freqVals,pwrEcogST,pwrEcogBL,LFPElectrodeList,EcogElectrodeList,parameterCombinations]= getResponses(gridType,folderSourceString,subjectName,expDate,protocolName,typeProtocol,tBL,tST,numTapers,stimIndsToChoose,fPos,dataDir,useNotchData)

if ~exist('useNotchData','var'), useNotchData=0; end
if ~exist('numTapers','var')||isempty(numTapers), numTapers = 3; end

estFlag=1;            % for MT 
%load(fullfile(folderSourceString,'data',subjectName,gridType,expDate,protocolName,[subjectName,expDate,protocolName,'ElectrodeList.mat']));   % load electrodes
% another option of loading elec list
dir1 = fullfile(gammaModelPath_st(),'Data');
[~,~,LFPElectrodeList,EcogElectrodeList,~] = getRFdetails(subjectName,dir1);
LFPElectrodeList=LFPElectrodeList{1}; EcogElectrodeList = EcogElectrodeList{1}; % unwrap them from cell.

parameterCombinations=load(fullfile(folderSourceString,'data',subjectName,gridType,expDate,protocolName,'extractedData','parameterCombinations.mat')); % ParameterCombinations
% some updates on parameter combinations
indsz = parameterCombinations.sValsUnique<0 | parameterCombinations.sValsUnique>11 ; % for sizes that are FullScreen 
parameterCombinations.sValsUnique(indsz) = 11.5; % Full Screen
[~,indor] = intersect(parameterCombinations.oValsUnique,[22 67 112 157]); % for oris at gap of 22.5 
parameterCombinations.oValsUnique(indor) = parameterCombinations.oValsUnique(indor)+0.5;

if strcmp(typeProtocol, 'Ori') || strcmp(typeProtocol, 'SFOri')
    % returns in terms of elec x sf x ori
    if ~isempty(LFPElectrodeList)
        [~,~,pwrST,pwrBL,freqVals]  = getFRandPowerSFOri2(subjectName,gridType,folderSourceString,expDate,protocolName, LFPElectrodeList ,tBL,tST,estFlag,numTapers,1,dataDir,useNotchData);
    else
        pwrST= {[]}; pwrBL= {[]};
    end
    if ~isempty(EcogElectrodeList)
        [~,~,pwrEcogST,pwrEcogBL,freqVals] = getFRandPowerSFOri2(subjectName,gridType,folderSourceString,expDate,protocolName,EcogElectrodeList ,tBL,tST,estFlag,numTapers,1,dataDir,useNotchData);
    else
        pwrEcogST={[]}; pwrEcogBL={[]};
    end
    % if only 1 SF available, then get it in elec x ori x sf
    if size(pwrST{1},2)==1 && size(pwrST{1},3)>1
        pwrST{1} = permute(pwrST{1},[1,3,2]); pwrBL{1} = permute(pwrBL{1},[1,3,2]);     
        pwrEcogST{1} = permute(pwrEcogST{1},[1,3,2]); pwrEcogBL{1} = permute(pwrEcogBL{1},[1,3,2]); %
    end
    
elseif strcmp(typeProtocol, 'SizeOri')
    % returns in terms of elec x size x ori
    if ~isempty(LFPElectrodeList)
        [~,~,pwrST,pwrBL,freqVals]  = getFRandPowerSizeOri2(subjectName,gridType,folderSourceString,expDate,protocolName,LFPElectrodeList , tBL,tST,estFlag,numTapers,1,dataDir,useNotchData);
    else
        pwrST= {[]}; pwrBL= {[]};
    end
    if ~isempty(EcogElectrodeList)
        [~,~,pwrEcogST,pwrEcogBL,freqVals] = getFRandPowerSizeOri2(subjectName,gridType,folderSourceString,expDate,protocolName,EcogElectrodeList ,tBL,tST,estFlag,numTapers,1,dataDir,useNotchData);
    else
        pwrEcogST={[]}; pwrEcogBL={[]};
    end 
    % drop sizes 0.05. they appear in only some protocols
    chooseS = parameterCombinations.sValsUnique>=0.09;
    parameterCombinations.sValsUnique = parameterCombinations.sValsUnique(chooseS);
    stimIndsToChoose = chooseS; % will be used later
    
elseif   strcmp(typeProtocol, 'ConTF') || strcmp(typeProtocol, 'ConOri')
    % returns in terms of elec x size x con x ori for static case
    chooseS = parameterCombinations.sValsUnique==11.5;  % full screen
    parameterCombinations.sValsUnique = parameterCombinations.sValsUnique(chooseS);
    if ~isempty(LFPElectrodeList)
        [~,~,pwrST,pwrBL,freqVals]  = getFRandPowerConOri2(subjectName,gridType,folderSourceString,expDate,protocolName,LFPElectrodeList , tBL,tST,estFlag,numTapers,1,dataDir,useNotchData);
        if ~iscell(pwrST),  pwrST={pwrST};  pwrBL={pwrBL}; end
        pwrST= cellfun(@(x) squeeze(x(:,chooseS,:,:)), pwrST,'un',0); pwrBL= cellfun(@(x) squeeze(x(:,chooseS,:,:)), pwrBL,'un',0);
    else
        pwrST= {[]}; pwrBL= {[]};
    end
    if ~isempty(EcogElectrodeList)
        [~,~,pwrEcogST,pwrEcogBL,freqVals] = getFRandPowerConOri2(subjectName,gridType,folderSourceString,expDate,protocolName,EcogElectrodeList ,tBL,tST,estFlag,numTapers,1,dataDir,useNotchData);
        if ~iscell(pwrEcogST),pwrEcogST= {pwrEcogST}; pwrEcogBL= {pwrEcogBL}; end
        pwrEcogST= cellfun(@(x) squeeze(x(:,chooseS,:,:)), pwrEcogST,'un',0); pwrEcogBL= cellfun(@(x) squeeze(x(:,chooseS,:,:)), pwrEcogBL,'un',0);
    else
        pwrEcogST={[]}; pwrEcogBL={[]};
    end   
    
elseif strcmp(typeProtocol, 'Images')
    if ~isempty(LFPElectrodeList)
        [~,~,pwrST,pwrBL,freqVals]  = getFRandPowerImage2(subjectName,gridType,folderSourceString,expDate,protocolName,LFPElectrodeList,tBL,tST,estFlag,numTapers,1,dataDir,useNotchData);
    else
        pwrST= {[]}; pwrBL= {[]};
    end
    if ~isempty(EcogElectrodeList)
        [~,~,pwrEcogST,pwrEcogBL,freqVals] = getFRandPowerImage2(subjectName,gridType,folderSourceString,expDate,protocolName,EcogElectrodeList ,tBL,tST,estFlag,numTapers,1,dataDir,useNotchData);
    else
        pwrEcogST={[]}; pwrEcogBL={[]};
    end
    
end  % end typeProtocol

if iscell(pwrST) && length(pwrST)==1,               % if values are 1x1 cells containing cells, unwrap them
    pwrST     = pwrST{1};      pwrBL     = pwrBL{1}; 
    pwrEcogST = pwrEcogST{1};  pwrEcogBL = pwrEcogBL{1}; 
end

% the following is just in case specific indices were sent in. as in case of images protocol. 
if ~isempty(fPos),
if ~isempty(pwrST),     pwrST     = pwrST(:,:,fPos);     pwrBL     = pwrBL(:,:,fPos);     end
if ~isempty(pwrEcogST), pwrEcogST = pwrEcogST(:,:,fPos); pwrEcogBL = pwrEcogBL(:,:,fPos); end
end
if ~isempty(stimIndsToChoose),
if ~isempty(pwrST),     pwrST     = pwrST(:,stimIndsToChoose,:);     pwrBL     = pwrBL(:,stimIndsToChoose,:);     end
if ~isempty(pwrEcogST), pwrEcogST = pwrEcogST(:,stimIndsToChoose,:); pwrEcogBL = pwrEcogBL(:,stimIndsToChoose,:); end
end

end


