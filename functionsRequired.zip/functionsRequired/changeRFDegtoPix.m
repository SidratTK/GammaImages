function [rfStatsP] = changeRFDegtoPix(rfStatsDeg1,DegPerPix,res,imgcenter)
% takes RF vals in degrees and converts them to pixel numbers using the resolution

if ~exist('imgcenter','var')
imgcenter=(1+res)/2;    % center of image
end

if ~iscell(rfStatsDeg1)
    rfStatsDeg = {rfStatsDeg1};
else
    rfStatsDeg = rfStatsDeg1;
end
for kk = 1:length(rfStatsDeg)
    rfStats=rfStatsDeg{kk};
    for el = 1:length(rfStats) 
        azi = imgcenter + rfStats(el).meanAzi/ DegPerPix;    % convert to pixel
        ele = imgcenter - rfStats(el).meanEle/ DegPerPix;
        sizeazi= rfStats(el).rfSizeAzi/ DegPerPix;
        sizeele= rfStats(el).rfSizeEle/ DegPerPix;
        rfStatsP{kk}(el).meanAzi = azi;
        rfStatsP{kk}(el).meanEle = ele;
        rfStatsP{kk}(el).rfSizeAzi = sizeazi;
        rfStatsP{kk}(el).rfSizeEle = sizeele;
    end  
end

end